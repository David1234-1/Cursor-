# StudyHub (Netlify + Supabase)

Site de gestion de cours (import PDF/TXT), génération IA (QCM, flashcards, résumés),
calendrier FullCalendar (CRUD), groupes + chat en temps réel, mode examen, SRS simple.
Design "Apple-clean" (Tailwind).

## Déploiement rapide (Netlify)

1) **Créer un projet Supabase** (ou utiliser le vôtre) et **activer Google OAuth** :
   - Auth > Providers > **Google**: Enabled ✅
   - Scopes: `email profile https://www.googleapis.com/auth/calendar`
   - Redirect URLs (add both): `http://localhost:5173/` and later your Netlify URL
2) **Appliquer les migrations SQL** : ouvrez Supabase SQL Editor et exécutez le contenu de `supabase/migrations.sql`.
   > Corrige `public.groups` manquant, crée toutes les tables + RLS.
3) **Créer le bucket Storage**: `courses` (public ou RLS selon besoin).
4) **Localement**:
   ```bash
   cp .env.example .env
   npm i
   npm run dev
   ```
5) **Netlify**:
   - Nouveau site > Importer dépôt ou **Déployer le zip**
   - Variables d'env (build & runtime): `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `OPENAI_API_KEY`
6) **Tester Google OAuth**: si vous voyez `Unsupported provider`, c'est que le provider n'est **pas activé** ou que la **Redirect URL** ne correspond pas exactement. Activez Google dans Supabase et réessayez.

### Fonctions serverless
- `functions/analyze-course.js` : appelle l'API OpenAI pour générer QCM / flashcards / résumé à partir du texte.
- `functions/push-google-event.js` : pousse un événement vers Google Calendar (si l'utilisateur a Google connecté avec scope calendar).

---

## Pages
- `/login` : email+password, Google
- `/` (Dashboard) : raccourcis, stats, dernières révisions
- `/calendar` : FullCalendar (jour / semaine / mois / à venir) + CRUD + sync Google optionnelle
- `/import` : PDF/TXT drag & drop, extraction pdf.js, envoi à l'IA, sauvegarde
- `/study` : flashcards (SRS) + QCM + résumés
- `/groups` : groupes + chat (Supabase Realtime)
- `/exam` : mode examen chronométré (QCM)
- `/settings` : thème, 2FA (si activé dans Supabase), liaison Google Calendar

---

🔒 **RLS** : toutes les tables sont protégées; un utilisateur ne voit que ses données.
🛟 **Offline** : contenu clé mis en cache (IndexedDB) pour consultation légère hors-ligne.
🎨 **UI** : Tailwind, focus states, dark mode, design responsive (mobile/tablette/desktop).
