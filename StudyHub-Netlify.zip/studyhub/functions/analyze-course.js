export default async (req, context) => {
  try {
    const body = await req.json()
    const { text, title } = body
    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) return new Response(JSON.stringify({ error: 'OPENAI_API_KEY manquant (Netlify > Environment variables)' }), { status: 500 })

    const prompt = [
      { role: "system", content: "Tu es un assistant pédagogique. Retourne du JSON strictement valide avec les clés: summary (string), flashcards (array of {front, back}), qcms (array of {question, options, answer}). 'answer' est l'index (0..3)." },
      { role: "user", content: `Cours: ${title}\n---\n${text.slice(0, 12000)}` }
    ]

    // Try the modern responses API if available, else fallback
    let completionRes
    try {
      completionRes = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: prompt,
          temperature: 0.3,
          response_format: { type: "json_object" }
        })
      })
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500 })
    }
    const data = await completionRes.json()
    if (data.error) return new Response(JSON.stringify({ error: data.error.message || 'OpenAI error' }), { status: 500 })

    const content = data.choices?.[0]?.message?.content
    let parsed
    try { parsed = JSON.parse(content) } catch (e) {
      parsed = { summary: content, flashcards: [], qcms: [] }
    }
    return new Response(JSON.stringify(parsed), { headers: { "Content-Type": "application/json" } })
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500 })
  }
}
