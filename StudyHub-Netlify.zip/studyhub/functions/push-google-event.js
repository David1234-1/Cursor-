export default async (req, context) => {
  try {
    const body = await req.json()
    const { access_token, event } = body
    if (!access_token) return new Response(JSON.stringify({ error: "Aucun access_token Google. Reconnectez-vous via Google avec le scope calendar." }), { status: 400 })
    const res = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${access_token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(event)
    })
    const j = await res.json()
    if (res.status >= 400) return new Response(JSON.stringify({ error: j.error?.message || 'Google Calendar error' }), { status: 400 })
    return new Response(JSON.stringify({ ok: true, id: j.id }))
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500 })
  }
}
