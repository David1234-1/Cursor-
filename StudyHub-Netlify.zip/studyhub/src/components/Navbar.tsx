import { Link, NavLink } from 'react-router-dom'
import { useSupa } from '../providers/SupaProvider'

export default function Navbar(){
  const { session } = useSupa()
  return (
    <header className="sticky top-0 z-40 border-b border-zinc-200/70 dark:border-zinc-800/70 bg-white/70 dark:bg-zinc-950/50 backdrop-blur">
      <div className="mx-auto max-w-7xl px-4 py-3 flex items-center gap-4">
        <Link to="/" className="font-semibold">StudyHub</Link>
        <nav className="flex items-center gap-2 text-sm">
          <NavLink to="/calendar" className="px-3 py-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10">Calendrier</NavLink>
          <NavLink to="/import" className="px-3 py-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10">Import</NavLink>
          <NavLink to="/study" className="px-3 py-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10">Révision</NavLink>
          <NavLink to="/groups" className="px-3 py-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10">Groupes</NavLink>
          <NavLink to="/exam" className="px-3 py-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10">Examen</NavLink>
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <Link to="/settings" className="btn-ghost">Réglages</Link>
          {session && <img src={`https://api.dicebear.com/9.x/identicon/svg?seed=${session.user.id}`} alt="" className="w-8 h-8 rounded-full"/>}
        </div>
      </div>
    </header>
  )
}
