import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider, redirect } from 'react-router-dom'
import './index.css'
import App from './pages/App'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import CalendarPage from './pages/CalendarPage'
import ImportPage from './pages/ImportPage'
import StudyPage from './pages/StudyPage'
import GroupsPage from './pages/GroupsPage'
import ExamPage from './pages/ExamPage'
import SettingsPage from './pages/SettingsPage'
import { SupaProvider, useSupa } from './providers/SupaProvider'

const Protected = ({ element }: { element: JSX.Element }) => {
  const { session, loading } = useSupa()
  if (loading) return <div className="p-6">Chargement...</div>
  if (!session) throw redirect('/login')
  return element
}

const router = createBrowserRouter([
  { path: '/login', element: <Login/> },
  { path: '/', element: <Protected element={<App/>} />, children: [
    { index: true, element: <Dashboard/> },
    { path: 'calendar', element: <CalendarPage/> },
    { path: 'import', element: <ImportPage/> },
    { path: 'study', element: <StudyPage/> },
    { path: 'groups', element: <GroupsPage/> },
    { path: 'exam', element: <ExamPage/> },
    { path: 'settings', element: <SettingsPage/> },
  ]},
  { path: '*', element: <div className="p-6">Page introuvable</div> }
])

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <SupaProvider>
      <RouterProvider router={router} />
    </SupaProvider>
  </React.StrictMode>
)
