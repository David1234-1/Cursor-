import { Outlet } from 'react-router-dom'
import Navbar from '../components/Navbar'

export default function App(){
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar/>
      <main className="mx-auto w-full max-w-7xl px-4 py-6 grow">
        <Outlet/>
      </main>
      <footer className="py-6 text-center text-sm text-zinc-500">© {new Date().getFullYear()} StudyHub</footer>
    </div>
  )
}
