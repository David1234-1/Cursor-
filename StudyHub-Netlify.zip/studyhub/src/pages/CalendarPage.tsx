import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
import timeGridPlugin from '@fullcalendar/timegrid'
import interactionPlugin from '@fullcalendar/interaction'
import listPlugin from '@fullcalendar/list'
import { useEffect, useState } from 'react'
import { supabase } from '../providers/SupaProvider'

type EventRow = {
  id: string
  user_id: string
  title: string
  start_at: string
  end_at: string | null
  category: string | null
  color: string | null
  details: any | null
}

export default function CalendarPage(){
  const [events, setEvents] = useState<EventRow[]>([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState<any>({ title: '', start_at: '', end_at: '', category: '', color: '#0A84FF' })

  const load = async () => {
    setLoading(true)
    const { data, error } = await supabase.from('events').select('*').order('start_at', { ascending: true })
    setLoading(false)
    if (error) return console.error(error)
    setEvents(data as EventRow[])
  }

  useEffect(() => {
    load()
    const channel = supabase.channel('events-changes').on('postgres_changes', {
      event: '*', schema: 'public', table: 'events'
    }, () => load()).subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [])

  const save = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.title || !form.start_at) return
    const { error } = await supabase.from('events').insert({
      title: form.title,
      start_at: form.start_at,
      end_at: form.end_at || null,
      category: form.category || null,
      color: form.color || null,
      details: { notes: form.notes || '' }
    })
    if (error) alert(error.message)
    else {
      setForm({ title: '', start_at: '', end_at: '', category: '', color: '#0A84FF' })
    }
  }

  const handleDateSelect = (info: any) => {
    setForm((f: any) => ({...f, start_at: info.startStr, end_at: info.endStr}))
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleEventChange = async (changeInfo: any) => {
    const e = changeInfo.event
    const { error } = await supabase.from('events').update({
      start_at: e.start?.toISOString(),
      end_at: e.end?.toISOString() || null,
      title: e.title
    }).eq('id', e.id)
    if (error) alert(error.message)
  }

  const handleEventClick = async (clickInfo: any) => {
    if (confirm('Supprimer cet évènement ?')) {
      const { error } = await supabase.from('events').delete().eq('id', clickInfo.event.id)
      if (error) alert(error.message)
    }
  }

  const pushGoogle = async (event: any) => {
    try {
      const s = (await supabase.auth.getSession()).data.session
      const access_token = s?.provider_token // often set for Google, if not, user must reconnect
      const res = await fetch('/.netlify/functions/push-google-event', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ access_token, event })
      })
      const j = await res.json()
      if (j.error) alert(j.error)
      else alert('Évènement créé dans Google Calendar ✅')
    } catch (e: any) {
      alert(e.message)
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="card md:col-span-1">
        <h2 className="text-lg font-semibold mb-2">Nouvel évènement</h2>
        <form className="space-y-3" onSubmit={save}>
          <div>
            <label className="label">Titre</label>
            <input className="input" value={form.title} onChange={e=>setForm({...form, title: e.target.value})} required/>
          </div>
          <div className="grid md:grid-cols-2 gap-3">
            <div>
              <label className="label">Début</label>
              <input className="input" type="datetime-local" value={form.start_at} onChange={e=>setForm({...form, start_at: e.target.value})} required/>
            </div>
            <div>
              <label className="label">Fin</label>
              <input className="input" type="datetime-local" value={form.end_at} onChange={e=>setForm({...form, end_at: e.target.value})}/>
            </div>
          </div>
          <div className="grid md:grid-cols-2 gap-3">
            <div>
              <label className="label">Catégorie</label>
              <input className="input" value={form.category} onChange={e=>setForm({...form, category: e.target.value})}/>
            </div>
            <div>
              <label className="label">Couleur</label>
              <input className="input" type="color" value={form.color} onChange={e=>setForm({...form, color: e.target.value})}/>
            </div>
          </div>
          <div>
            <label className="label">Notes</label>
            <textarea className="input" rows={3} value={form.notes || ''} onChange={e=>setForm({...form, notes: e.target.value})}/>
          </div>
          <div className="flex gap-2">
            <button className="btn-primary" type="submit">Enregistrer</button>
            <button type="button" className="btn-ghost" onClick={()=>pushGoogle({
              summary: form.title,
              start: { dateTime: form.start_at },
              end: { dateTime: form.end_at || form.start_at },
            })}>Sync Google</button>
          </div>
        </form>
      </div>

      <div className="md:col-span-2 card">
        <FullCalendar
          plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin, listPlugin]}
          initialView="dayGridMonth"
          headerToolbar={{
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
          }}
          editable
          selectable
          selectMirror
          select={handleDateSelect}
          eventDrop={handleEventChange}
          eventResize={handleEventChange}
          eventClick={handleEventClick}
          events={events.map(e => ({
            id: e.id,
            title: e.title,
            start: e.start_at,
            end: e.end_at || undefined,
            backgroundColor: e.color || undefined,
            borderColor: e.color || undefined
          }))}
          height="80vh"
        />
        {loading && <p className="mt-2 text-sm">Chargement…</p>}
      </div>
    </div>
  )
}
