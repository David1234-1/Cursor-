import { Link } from 'react-router-dom'
import Stats from '../ui/Stats'

export default function Dashboard(){
  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Accès rapide</h2>
        <div className="grid grid-cols-2 gap-2">
          <Link to="/calendar" className="btn-ghost">📅 Calendrier</Link>
          <Link to="/import" className="btn-ghost">📂 Import</Link>
          <Link to="/study" className="btn-ghost">📝 Révision</Link>
          <Link to="/groups" className="btn-ghost">👥 Groupes</Link>
        </div>
      </div>
      <Stats/>
      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Derniers cours</h2>
        <p className="text-sm text-zinc-500">S’affichent après import.</p>
      </div>
    </div>
  )
}
