import { useEffect, useState } from 'react'
import { supabase } from '../providers/SupaProvider'

type Q = { id: string, question: string, options: string[], answer: number }

export default function ExamPage(){
  const [qs, setQs] = useState<Q[]>([])
  const [idx, setIdx] = useState(0)
  const [sel, setSel] = useState<number|null>(null)
  const [score, setScore] = useState(0)
  const [timer, setTimer] = useState(60*10) // 10 minutes

  useEffect(()=>{
    const load = async () => {
      const { data } = await supabase.from('qcms').select('id,question,options,answer').limit(20)
      setQs(data || [])
    }; load()
    const t = setInterval(()=> setTimer(s=> Math.max(0, s-1)), 1000)
    return ()=> clearInterval(t)
  }, [])

  useEffect(()=>{
    if (timer===0) alert('Temps écoulé ! Score: '+score+'/'+qs.length)
  }, [timer])

  const submit = () => {
    if (sel===null) return
    if (sel===qs[idx].answer) setScore(s=>s+1)
    setSel(null)
    setIdx(i=> i+1)
  }

  if (!qs.length) return <div className="card">Aucun QCM disponible.</div>
  if (idx>=qs.length) return <div className="card">Fini ! Score: <b>{score}/{qs.length}</b></div>
  const q = qs[idx]

  return (
    <div className="card">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-lg font-semibold">Examen</h2>
        <div className="text-sm">⏱️ {Math.floor(timer/60)}:{String(timer%60).padStart(2,'0')}</div>
      </div>
      <div className="font-medium mb-2">{q.question}</div>
      <ul className="space-y-2">
        {q.options.map((o,i)=>(
          <li key={i}>
            <label className={"flex items-center gap-2 px-3 py-2 rounded-xl border " + (sel===i?'border-brand':'border-zinc-200 dark:border-zinc-800')}>
              <input type="radio" name="opt" checked={sel===i} onChange={()=>setSel(i)}/>
              <span>{o}</span>
            </label>
          </li>
        ))}
      </ul>
      <button className="btn-primary mt-3" onClick={submit}>Valider</button>
    </div>
  )
}
