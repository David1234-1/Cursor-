import { useEffect, useState } from 'react'
import { supabase } from '../providers/SupaProvider'

type Group = { id: string, name: string, owner_id: string }
type Msg = { id: string, group_id: string, user_id: string, content: string, created_at: string }

export default function GroupsPage(){
  const [groups, setGroups] = useState<Group[]>([])
  const [current, setCurrent] = useState<Group|null>(null)
  const [message, setMessage] = useState('')

  const loadGroups = async () => {
    const { data } = await supabase.from('groups').select('*').order('created_at', { ascending: false })
    setGroups(data || [])
  }
  useEffect(()=>{ loadGroups() }, [])

  const createGroup = async () => {
    const name = prompt('Nom du groupe ?')
    if (!name) return
    const { data, error } = await supabase.from('groups').insert({ name }).select('*').single()
    if (error) return alert(error.message)
    await supabase.from('group_members').insert({ group_id: data.id })
    setGroups(g=>[data, ...g])
  }

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="card">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-lg font-semibold">Groupes</h2>
          <button className="btn-primary" onClick={createGroup}>Nouveau</button>
        </div>
        <ul className="space-y-1">
          {groups.map(g=>(
            <li key={g.id}>
              <button className={"w-full text-left px-3 py-2 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 " + (current?.id===g.id?'bg-black/5 dark:bg-white/5':'')} onClick={()=>setCurrent(g)}>{g.name}</button>
            </li>
          ))}
        </ul>
      </div>
      <div className="md:col-span-2 card">
        {current ? <Chat group={current} message={message} setMessage={setMessage}/> : <p>Sélectionnez un groupe.</p>}
      </div>
    </div>
  )
}

function Chat({ group, message, setMessage }:{ group: Group, message: string, setMessage: (v:string)=>void }){
  const [msgs, setMsgs] = useState<Msg[]>([])

  const load = async () => {
    const { data } = await supabase.from('messages').select('*').eq('group_id', group.id).order('created_at', { ascending: true })
    setMsgs(data || [])
  }
  useEffect(()=>{ load() }, [group.id])

  useEffect(()=>{
    const channel = supabase.channel('msg-'+group.id).on('postgres_changes', {
      event: 'INSERT', schema:'public', table:'messages', filter: `group_id=eq.${group.id}`
    }, payload => {
      setMsgs(m => [...m, payload.new as any])
    }).subscribe()
    return ()=>{ supabase.removeChannel(channel) }
  }, [group.id])

  const send = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return
    const { error } = await supabase.from('messages').insert({ group_id: group.id, content: message.trim() })
    if (error) alert(error.message)
    else setMessage('')
  }

  return (
    <div className="flex flex-col h-[70vh]">
      <div className="grow overflow-y-auto space-y-2">
        {msgs.map(m=>(
          <div key={m.id} className="px-3 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 w-fit">{m.content}</div>
        ))}
      </div>
      <form onSubmit={send} className="mt-3 flex gap-2">
        <input className="input" value={message} onChange={e=>setMessage(e.target.value)} placeholder="Message..." />
        <button className="btn-primary">Envoyer</button>
      </form>
    </div>
  )
}
