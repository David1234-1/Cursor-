import { useState } from 'react'
import { supabase } from '../providers/SupaProvider'
import * as pdfjsLib from 'pdfjs-dist'
//@ts-ignore
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.min.js?url'

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker

type FileItem = { name: string, progress: number, status: 'queued'|'extracting'|'analyzing'|'done'|'error', text?: string, error?: string }

export default function ImportPage(){
  const [files, setFiles] = useState<FileItem[]>([])
  const [busy, setBusy] = useState(false)

  const handleFiles = (list: FileList|null) => {
    if (!list) return
    const arr = Array.from(list)
    const items = arr.map(f => ({ name: f.name, progress: 0, status: 'queued' as const, file: f }))
    // @ts-ignore
    setFiles(prev => [...prev, ...items])
  }

  const extractText = async (file: File) => {
    if (file.name.toLowerCase().endsWith('.txt')) {
      const t = await file.text()
      return t
    }
    // PDF
    const buf = await file.arrayBuffer()
    const pdf = await pdfjsLib.getDocument({ data: buf }).promise
    let text = ''
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i)
      const content = await page.getTextContent()
      text += content.items.map((i: any)=> i.str).join(' ') + '\n'
    }
    return text
  }

  const analyze = async (text: string, title: string) => {
    const res = await fetch('/.netlify/functions/analyze-course', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, title })
    })
    return res.json()
  }

  const start = async () => {
    if (busy) return
    setBusy(true)
    for (let i = 0; i < files.length; i++) {
      // @ts-ignore
      const f = files[i].file as File
      try {
        setFiles(fs => fs.map((x, idx)=> idx===i? {...x, status:'extracting', progress: 10}:x))
        const text = await extractText(f)
        setFiles(fs => fs.map((x, idx)=> idx===i? {...x, status:'analyzing', progress: 50}:x))

        // Save course
        const { data: course, error } = await supabase.from('courses').insert({
          title: f.name.replace(/\.(pdf|txt)$/i, ''), file_name: f.name, content: text
        }).select('*').single()
        if (error) throw error

        const result = await analyze(text, course.title)
        if (result.error) throw new Error(result.error)

        // Persist generated data
        if (result.summary) await supabase.from('summaries').insert({ course_id: course.id, content: result.summary })
        if (Array.isArray(result.flashcards)) await supabase.from('flashcards').insert(result.flashcards.map((fc: any)=> ({ course_id: course.id, front: fc.front, back: fc.back })))
        if (Array.isArray(result.qcms)) await supabase.from('qcms').insert(result.qcms.map((q: any)=> ({ course_id: course.id, question: q.question, options: q.options, answer: q.answer })))

        setFiles(fs => fs.map((x, idx)=> idx===i? {...x, status:'done', progress: 100, text}:x))
      } catch (e: any) {
        setFiles(fs => fs.map((x, idx)=> idx===i? {...x, status:'error', error: e.message}:x))
      }
    }
    setBusy(false)
  }

  return (
    <div className="card">
      <h2 className="text-lg font-semibold mb-2">Importer des cours (PDF/TXT)</h2>
      <div className="flex items-center gap-3">
        <input type="file" multiple accept=".pdf,.txt" onChange={e=>handleFiles(e.target.files)}/>
        <button className="btn-primary" onClick={start} disabled={busy}>Lancer l'analyse</button>
      </div>
      <ul className="mt-4 space-y-2">
        {files.map((f,i)=>(
          <li key={i} className="p-3 rounded-xl border border-zinc-200 dark:border-zinc-800">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">{f.name}</div>
                <div className="text-sm text-zinc-500">{f.status}</div>
              </div>
              <div className="w-48 h-2 bg-zinc-200 dark:bg-zinc-800 rounded overflow-hidden">
                <div className="h-full bg-brand" style={{width: f.progress+'%'}}/>
              </div>
            </div>
            {f.error && <div className="text-sm text-red-600 mt-1">{f.error}</div>}
          </li>
        ))}
      </ul>
    </div>
  )
}
