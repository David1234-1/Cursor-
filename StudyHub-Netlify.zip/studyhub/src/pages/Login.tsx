import { FormEvent, useState } from 'react'
import { supabase } from '../providers/SupaProvider'
import { useNavigate } from 'react-router-dom'

export default function Login(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string|null>(null)
  const nav = useNavigate()

  const onEmailPassword = async (e: FormEvent) => {
    e.preventDefault()
    setErr(null); setLoading(true)
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    setLoading(false)
    if (error) return setErr(error.message)
    if (data.session) nav('/')
  }

  const onGoogle = async () => {
    setErr(null)
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        scopes: 'email profile https://www.googleapis.com/auth/calendar',
        redirectTo: window.location.origin
      }
    })
    if (error) {
      // Provider non activé : message clair
      setErr(error.message + " — Activez Google dans Supabase > Auth > Providers et ajoutez l'URL de redirection.")
    }
  }

  const onReset = async () => {
    if (!email) return setErr('Entrez votre email puis cliquez sur "Mot de passe oublié".')
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin })
    if (error) setErr(error.message)
    else setErr('Email de réinitialisation envoyé (si un compte existe).')
  }

  return (
    <div className="max-w-md mx-auto mt-16 card">
      <h1 className="heading mb-2">Connexion</h1>
      <p className="text-sm text-zinc-500 mb-4">Email + mot de passe ou Google.</p>
      <form onSubmit={onEmailPassword} className="space-y-3">
        <div>
          <label className="label">Email</label>
          <input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} required/>
        </div>
        <div>
          <label className="label">Mot de passe</label>
          <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} required/>
        </div>
        <div className="flex gap-2">
          <button className="btn-primary" disabled={loading} type="submit">Se connecter</button>
          <button className="btn-ghost" type="button" onClick={onReset}>Mot de passe oublié</button>
          <button className="btn-ghost ml-auto" type="button" onClick={onGoogle}>Google</button>
        </div>
        {err && <p className="text-sm text-red-600">{err}</p>}
      </form>
    </div>
  )
}
