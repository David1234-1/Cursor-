import { supabase, useSupa } from '../providers/SupaProvider'

export default function SettingsPage(){
  const { session } = useSupa()
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Compte</h2>
        <p className="text-sm">Email: <b>{session?.user.email}</b></p>
        <div className="mt-3 flex gap-2">
          <button className="btn-ghost" onClick={()=>supabase.auth.signOut()}>Se déconnecter</button>
          <button className="btn-primary" onClick={()=>supabase.auth.signInWithOAuth({ provider:'google', options:{ scopes:'email profile https://www.googleapis.com/auth/calendar', redirectTo: window.location.origin }})}>Connecter Google</button>
        </div>
        <p className="text-xs text-zinc-500 mt-2">Si vous voyez une erreur "Unsupported provider", activez **Google** dans Supabase & renseignez les Redirect URLs.</p>
      </div>
      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Thème</h2>
        <div className="flex gap-2">
          <button className="btn-ghost" onClick={()=>document.documentElement.classList.remove('dark')}>Clair</button>
          <button className="btn-ghost" onClick={()=>document.documentElement.classList.add('dark')}>Sombre</button>
        </div>
      </div>
    </div>
  )
}
