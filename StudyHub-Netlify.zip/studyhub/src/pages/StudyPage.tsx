import { useEffect, useState } from 'react'
import { supabase } from '../providers/SupaProvider'

type Flashcard = { id: string, course_id: string, front: string, back: string }
type Q = { id: string, course_id: string, question: string, options: string[], answer: number }

export default function StudyPage(){
  const [flashcards, setFlashcards] = useState<Flashcard[]>([])
  const [qcms, setQcms] = useState<Q[]>([])
  const [idx, setIdx] = useState(0)
  const [showBack, setShowBack] = useState(false)

  const load = async () => {
    const fcs = await supabase.from('flashcards').select('*').limit(50)
    const qs = await supabase.from('qcms').select('*').limit(50)
    setFlashcards(fcs.data || [])
    setQcms(qs.data || [])
  }
  useEffect(()=>{ load() }, [])

  const fc = flashcards[idx]
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Flashcards (SRS simple)</h2>
        {fc ? (
          <div>
            <div className="p-6 rounded-xl bg-zinc-100 dark:bg-zinc-800 cursor-pointer select-none min-h-[140px]" onClick={()=>setShowBack(s=>!s)}>
              {!showBack ? <div>{fc.front}</div> : <div className="font-semibold">{fc.back}</div>}
            </div>
            <div className="mt-3 flex gap-2">
              <button className="btn-ghost" onClick={()=>{ setShowBack(false); setIdx(i=> (i+1)%flashcards.length) }}>Je passe</button>
              <button className="btn-primary" onClick={()=>{ setShowBack(false); setIdx(i=> (i+1)%flashcards.length) }}>Je sais</button>
            </div>
          </div>
        ): <p>Aucune carte pour l’instant.</p>}
      </div>

      <div className="card">
        <h2 className="text-lg font-semibold mb-2">QCM rapide</h2>
        {qcms[0] ? <Qcm q={qcms[0]}/> : <p>Aucun QCM pour l’instant.</p>}
      </div>
    </div>
  )
}

function Qcm({ q }: { q: Q }){
  const [selected, setSelected] = useState<number|null>(null)
  return (
    <div>
      <div className="font-medium">{q.question}</div>
      <ul className="mt-3 space-y-2">
        {q.options.map((opt, i)=>(
          <li key={i}>
            <button onClick={()=>setSelected(i)} className={"w-full text-left px-3 py-2 rounded-xl border " + (selected===i ? 'border-brand' : 'border-zinc-200 dark:border-zinc-800')}>
              {String.fromCharCode(65+i)}. {opt}
            </button>
          </li>
        ))}
      </ul>
      {selected!==null && <div className="mt-3">
        {selected===q.answer ? <div className="text-green-600">✅ Correct</div> : <div className="text-red-600">❌ Faux — Rép: {String.fromCharCode(65+q.answer)}</div>}
      </div>}
    </div>
  )
}
