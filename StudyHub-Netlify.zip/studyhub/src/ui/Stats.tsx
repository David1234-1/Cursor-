export default function Stats(){
  // Fake values for the UI; real stats come from DB on /study
  return (
    <div className="card">
      <h2 className="text-lg font-semibold mb-2">Statistiques</h2>
      <ul className="text-sm space-y-1">
        <li>⏱️ Temps d’étude (7j): <b>4h 20m</b></li>
        <li>✅ Taux réussite QCM: <b>78%</b></li>
        <li>🧠 Cartes révisées hier: <b>56</b></li>
      </ul>
    </div>
  )
}
