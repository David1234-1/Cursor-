-- Enable extensions
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- Profiles (optional)
create table if not exists profiles (
  id uuid primary key default auth.uid(),
  full_name text,
  created_at timestamp with time zone default now()
);

-- Events
create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  title text not null,
  start_at timestamp with time zone not null,
  end_at timestamp with time zone,
  category text,
  color text,
  details jsonb,
  created_at timestamp with time zone default now()
);

-- Courses
create table if not exists courses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  title text,
  file_name text,
  content text,
  created_at timestamp with time zone default now()
);

-- QCMs
create table if not exists qcms (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references courses(id) on delete cascade,
  question text,
  options text[],
  answer int,
  created_at timestamp with time zone default now()
);

-- Flashcards
create table if not exists flashcards (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references courses(id) on delete cascade,
  front text,
  back text,
  created_at timestamp with time zone default now()
);

-- Summaries
create table if not exists summaries (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references courses(id) on delete cascade,
  content text,
  created_at timestamp with time zone default now()
);

-- Groups
create table if not exists groups (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  owner_id uuid not null default auth.uid(),
  created_at timestamp with time zone default now()
);

-- Group members
create table if not exists group_members (
  group_id uuid references groups(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  joined_at timestamp with time zone default now(),
  primary key(group_id, user_id)
);

-- Messages
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  group_id uuid references groups(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  content text not null,
  created_at timestamp with time zone default now()
);

-- SRS Reviews (simple log)
create table if not exists srs_reviews (
  id uuid primary key default gen_random_uuid(),
  flashcard_id uuid references flashcards(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  rating int check (rating between 0 and 5),
  reviewed_at timestamp with time zone default now()
);

alter table profiles enable row level security;
alter table events enable row level security;
alter table courses enable row level security;
alter table qcms enable row level security;
alter table flashcards enable row level security;
alter table summaries enable row level security;
alter table groups enable row level security;
alter table group_members enable row level security;
alter table messages enable row level security;
alter table srs_reviews enable row level security;

-- Users can manage their own rows
create policy if not exists "own_profile" on profiles for all using (id = auth.uid()) with check (id = auth.uid());
create policy if not exists "own_events" on events for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy if not exists "own_courses" on courses for all using (user_id = auth.uid()) with check (user_id = auth.uid());
-- Child tables via join
create policy if not exists "child_qcms" on qcms for all using (
  exists (select 1 from courses c where c.id = qcms.course_id and c.user_id = auth.uid())
) with check (exists (select 1 from courses c where c.id = qcms.course_id and c.user_id = auth.uid()));
create policy if not exists "child_flashcards" on flashcards for all using (
  exists (select 1 from courses c where c.id = flashcards.course_id and c.user_id = auth.uid())
) with check (exists (select 1 from courses c where c.id = flashcards.course_id and c.user_id = auth.uid()));
create policy if not exists "child_summaries" on summaries for all using (
  exists (select 1 from courses c where c.id = summaries.course_id and c.user_id = auth.uid())
) with check (exists (select 1 from courses c where c.id = summaries.course_id and c.user_id = auth.uid()));

-- Groups: members can read; owners & members can write; only owner can delete group
create policy if not exists "groups_read" on groups for select using (
  exists (select 1 from group_members gm where gm.group_id = groups.id and gm.user_id = auth.uid())
  or groups.owner_id = auth.uid()
);
create policy if not exists "groups_insert" on groups for insert with check (owner_id = auth.uid());
create policy if not exists "groups_update" on groups for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy if not exists "groups_delete" on groups for delete using (owner_id = auth.uid());

create policy if not exists "members_read" on group_members for select using (
  user_id = auth.uid() or exists (select 1 from groups g where g.id = group_members.group_id and g.owner_id = auth.uid())
);
create policy if not exists "members_insert" on group_members for insert with check (user_id = auth.uid());
create policy if not exists "members_delete" on group_members for delete using (user_id = auth.uid() or exists (select 1 from groups g where g.id = group_members.group_id and g.owner_id = auth.uid()));

create policy if not exists "messages_sel" on messages for select using (
  exists (select 1 from group_members gm where gm.group_id = messages.group_id and gm.user_id = auth.uid())
);
create policy if not exists "messages_ins" on messages for insert with check (
  exists (select 1 from group_members gm where gm.group_id = messages.group_id and gm.user_id = auth.uid())
);
create policy if not exists "messages_del" on messages for delete using (
  user_id = auth.uid()
);
